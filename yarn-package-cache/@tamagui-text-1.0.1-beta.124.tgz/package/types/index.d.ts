export * from './SizableText';
export * from './Paragraph';
export * from './Headings';
export * from './wrapChildrenInText';
export * from './types';
//# sourceMappingURL=index.d.ts.map