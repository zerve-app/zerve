/// <reference types="react" />
import { DismissableBranchProps, DismissableProps } from './DismissableProps';
export declare const Dismissable: import("react").ForwardRefExoticComponent<DismissableProps & import("react").RefAttributes<unknown>>;
export declare const DismissableBranch: import("react").ForwardRefExoticComponent<DismissableBranchProps & import("react").RefAttributes<unknown>>;
//# sourceMappingURL=Dismissable.native.d.ts.map