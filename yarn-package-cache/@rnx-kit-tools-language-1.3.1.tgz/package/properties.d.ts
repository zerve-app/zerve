export * from "./lib/properties";
