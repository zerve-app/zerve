/**
 * Convert an array offset to an array index. An offset can be positive or
 * negative, while an index is always positive.
 *
 * A negative offset is converted to an index starting from end of the array,
 * and counting backwards toward the front.
 *
 * @param array Array
 * @param offset Offset
 * @returns
 */
export declare function toIndex<T>(array: readonly T[], offset: number): number;
/**
 * Add elements from one array to another, returning the resulting array.
 *
 * Elements are added in-place. `undefined` elements are skipped. When `to`
 * isn't set, a new array is returned.
 *
 * @param to Elements are added to this array. If `undefined`, a new array is created.
 * @param from Elements are read from this array. `undefined` elements are skipped.
 * @param start Optional. Starting offset of the range for reading `from` elements. Defaults to `0`.
 * @param end Optional. Ending offset of the range for reading `from` elements. Defaults to `from.length`.
 * @returns Array containing `to` and `from` elements.
 */
export declare function addRange<T>(to: T[] | undefined, from: readonly T[] | undefined, start?: number, end?: number): T[] | undefined;
/**
 * Returns whether the specified object is a non-empty array.
 * @param array The array to check
 */
export declare function isNonEmptyArray<T = unknown>(array: unknown): array is T[];
//# sourceMappingURL=array.d.ts.map