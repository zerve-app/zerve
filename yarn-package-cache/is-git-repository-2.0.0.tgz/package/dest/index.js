"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var execa_1 = __importDefault(require("execa"));

var path_1 = __importDefault(require("path"));

var is_absolute_1 = __importDefault(require("is-absolute"));

var processCwd = process.cwd();

var isGit = function (altPath) {
  if (altPath === void 0) {
    altPath = processCwd;
  }

  var cwd = is_absolute_1.default(altPath) ? altPath : path_1.default.join(processCwd, altPath);

  try {
    execa_1.default.commandSync('git rev-parse --is-inside-work-tree', {
      cwd: cwd
    });
    return true;
  } catch (_a) {
    return false;
  }
};

exports.default = isGit;
module.exports = exports.default;