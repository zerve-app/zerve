/**
 * Escape a path by replacing each backslash ('\\') with a double-backslash ("\\\\").
 *
 * @param p Path to escape
 * @returns Escaped path
 */
export declare function escapePath(p: string): string;
/**
 * Normalize the separators in a path, converting each backslash ('\\') to a foreward
 * slash ('/').
 *
 * @param p Path to normalize
 * @returns Normalized path
 */
export declare function normalizePath(p: string): string;
//# sourceMappingURL=path.d.ts.map