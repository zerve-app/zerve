/**
 * Components of a package reference.
 */
export declare type PackageRef = {
    scope?: string;
    name: string;
};
/**
 * Parse a package reference string. An example reference is the `name`
 * property found in `package.json`.
 *
 * @param r Package reference string
 * @returns Parsed package reference object
 */
export declare function parsePackageRef(r: string): PackageRef;
/**
 * Get the mangled name for a package reference.
 *
 * @param ref Package reference
 * @returns Mangled name
 */
export declare function getMangledPackageName(ref: PackageRef): string;
/**
 * Schema for a reference to a person in `package.json`.
 */
export declare type PackagePerson = string | {
    name: string;
    email?: string;
    url?: string;
};
/**
 * Schema for the contents of a `package.json` manifest file.
 */
export declare type PackageManifest = {
    name: string;
    version: string;
    private?: boolean;
    typings?: string;
    types?: string;
    scripts?: Record<string, string>;
    dependencies?: Record<string, string>;
    peerDependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
    author?: PackagePerson;
    "rnx-kit"?: Record<string, unknown>;
    [key: string]: string | boolean | string[] | Record<string, unknown> | undefined;
};
/**
 * Determine if the given object is a `package.json` manifest.
 *
 * @param manifest Object to evaluate
 * @returns `true` if the object is a manifest
 */
export declare function isPackageManifest(manifest: unknown): manifest is PackageManifest;
/**
 * Read a `package.json` manifest from a file.
 *
 * @param pkgPath Either a path directly to the target `package.json` file, or the directory containing it.
 * @returns Package manifest
 */
export declare function readPackage(pkgPath: string): PackageManifest;
/**
 * Write a `package.json` manifest to a file.
 *
 * @param pkgPath Either a path directly to the target `package.json` file, or the directory containing it.
 * @param manifest Package manifest
 * @param space Indentation to apply to the output
 */
export declare function writePackage(pkgPath: string, manifest: PackageManifest, space?: string): void;
/**
 * Find the nearest `package.json` manifest file. Search upward through all
 * parent directories.
 *
 * If a starting directory is given, use it. Otherwise, use the current working
 * directory.
 *
 * @param startDir Optional starting directory for the search. If not given, the current directory is used.
 * @returns Path to `package.json`, or `undefined` if not found.
 */
export declare function findPackage(startDir?: string): string | undefined;
/**
 * Find the parent directory of the nearest `package.json` manifest file. Search
 * upward through all parent directories.
 *
 * If a starting directory is given, use it. Otherwise, use the current working
 * directory.
 *
 * @param startDir Optional starting directory for the search. If not given, the current directory is used.
 * @returns Path to `package.json`, or `undefined` if not found.
 */
export declare function findPackageDir(startDir?: string): string | undefined;
/**
 * Options which control how package dependecies are located.
 */
export declare type FindPackageDependencyOptions = {
    /**
     * Optional starting directory for the search. Defaults to `process.cwd()`.
     */
    startDir?: string;
    /**
     * Optional flag controlling whether or symlinks can be found. Defaults to `true`.
     * When `false`, and the package dependency directory is a symlink, it will not
     * be found.
     */
    allowSymlinks?: boolean;
};
/**
 * Find the package dependency's directory, starting from the given directory
 * and moving outward, through all parent directories.
 *
 * Package dependencies exist under 'node_modules/[`scope`]/[`name`]'.
 *
 * @param ref Package dependency reference
 * @param options Options which control the search
 * @returns Path to the package dependency's directory, or `undefined` if not found.
 */
export declare function findPackageDependencyDir(ref: string | PackageRef, options?: FindPackageDependencyOptions): string | undefined;
//# sourceMappingURL=package.d.ts.map