/// <reference types="node" />
import fs from "fs";
/**
 * Combine the root directory with each relative file, testing whether or not the file exists.
 * Stop and return as soon as a file is found.
 *
 * @param rootDir Root directory for each file.
 * @param relativeFiles Relative path of each file. `falsey` entries are ignored.
 * @returns Absolute path of the first file that exists, or `undefined`.
 */
export declare function findFirstFileExists(rootDir: string, ...relativeFiles: string[]): string | undefined;
/**
 * Create a directory, and all missing parent directories.
 *
 * @param p Directory to create
 */
export declare function createDirectory(p: string): void;
/**
 * Get stats (detailed information) for the target path.
 *
 * @param p Target path
 * @returns Stats data, or `undefined` if stats aren't available.
 */
export declare function statSync(p: string): fs.Stats | undefined;
/**
 * Determine if the target path refers to a directory.
 *
 * @param p Target path
 * @returns Returns `true` if the path refers to a directory, or `false` if it doesn't.
 */
export declare function isDirectory(p: string): boolean;
/**
 * Determine if the target path refers to a file.
 *
 * @param p Target path
 * @returns Returns `true` if the path refers to a file, or `false` if it doesn't.
 */
export declare function isFile(p: string): boolean;
//# sourceMappingURL=fs.d.ts.map