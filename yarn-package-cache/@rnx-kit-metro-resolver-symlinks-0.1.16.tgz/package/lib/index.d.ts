import type { MetroResolver, Options } from "./types";
declare function makeResolver({ remapModule, }?: Options): MetroResolver;
declare namespace makeResolver {
    var remapImportPath: typeof import("./utils/remapImportPath").remapImportPath;
}
export = makeResolver;
//# sourceMappingURL=index.d.ts.map