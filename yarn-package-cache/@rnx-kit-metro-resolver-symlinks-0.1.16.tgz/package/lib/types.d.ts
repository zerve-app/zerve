import type { ResolutionContext as MetroResolutionContext } from "metro-resolver";
export declare type MetroResolver = typeof import("metro-resolver").resolve;
export declare type ResolutionContext = Pick<MetroResolutionContext, "originModulePath">;
export declare type ModuleResolver = (context: ResolutionContext, moduleName: string, platform: string) => string;
export declare type Options = {
    remapModule?: ModuleResolver;
};
//# sourceMappingURL=types.d.ts.map