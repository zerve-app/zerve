import type { MetroResolver, ModuleResolver } from "./types";
/**
 * Get `metro-resolver` from the cli to avoid adding another dependency that
 * needs to be kept in sync.
 */
export declare function getMetroResolver(fromDir?: string): MetroResolver;
export declare const remapReactNativeModule: ModuleResolver;
export declare const resolveModulePath: ModuleResolver;
//# sourceMappingURL=resolver.d.ts.map