import type { PackageModuleRef } from "@rnx-kit/tools-node";
import type { ModuleResolver, ResolutionContext } from "../types";
declare type Resolver = (fromDir: string, moduleId: string) => string;
declare type ResolverOptions = {
    extensions: string[];
    mainFields: string[];
};
declare type Options = Partial<ResolverOptions> & {
    test: (moduleName: string) => boolean;
};
export declare function remapLibToSrc({ originModulePath }: ResolutionContext, ref: PackageModuleRef, resolver: Resolver): string | undefined;
export declare function resolveModule(fromDir: string, moduleId: string, resolver: Resolver, { mainFields }: ResolverOptions): string;
export declare function resolveModulePath({ originModulePath }: ResolutionContext, ref: PackageModuleRef, resolver: Resolver, options: ResolverOptions): PackageModuleRef;
export declare function remapImportPath(pluginOptions: Options): ModuleResolver;
export {};
//# sourceMappingURL=remapImportPath.d.ts.map