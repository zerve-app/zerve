/**
 * List of supported react-native platforms.
 */
export declare type AllPlatforms = "ios" | "android" | "windows" | "win32" | "macos";
/**
 * Returns a list of extensions that should be tried for the target platform in
 * prioritized order.
 * @param platform The platform to expand platform extensions for
 * @param extensions A list of extensions to expand
 * @returns A list of extensions
 */
export declare function expandPlatformExtensions(platform: string, extensions: string[]): string[];
/**
 * Returns a map of available React Native platforms. The result is cached.
 * @privateRemarks is-arrow-function
 * @param startDir The directory to look for react-native platforms from
 * @returns A platform-to-npm-package map, excluding "core" platforms.
 */
export declare const getAvailablePlatforms: (startDir?: string) => Record<string, string>;
/**
 * Returns a map of available React Native platforms. The result is NOT cached.
 * @param startDir The directory to look for react-native platforms from
 * @param platformMap A platform-to-npm-package map of known packages
 * @returns A platform-to-npm-package map, excluding "core" platforms.
 */
export declare function getAvailablePlatformsUncached(startDir?: string, platformMap?: Record<string, string>): Record<string, string>;
/**
 * Returns file extensions that can be mapped to the target platform.
 * @param platform The platform to retrieve extensions for
 * @returns Valid extensions for specified platform
 */
export declare function platformExtensions(platform: string): string[];
/**
 * Parse a string to ensure it maps to a valid react-native platform.
 *
 * @param val Input string
 * @returns React-native platform name. Throws `Error` on failure.
 */
export declare function parsePlatform(val: string): AllPlatforms;
//# sourceMappingURL=platform.d.ts.map