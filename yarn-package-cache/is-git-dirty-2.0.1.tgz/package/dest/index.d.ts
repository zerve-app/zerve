declare const isGitClean: (cwd?: string) => boolean | null;
export default isGitClean;
