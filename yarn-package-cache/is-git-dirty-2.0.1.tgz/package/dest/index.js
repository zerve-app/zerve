"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var execa_1 = __importDefault(require("execa"));

var is_git_repository_1 = __importDefault(require("is-git-repository"));

var processCwd = process.cwd();

var isGitClean = function (cwd) {
  if (cwd === void 0) {
    cwd = processCwd;
  }

  if (!is_git_repository_1.default(cwd)) {
    return null;
  }

  try {
    var stdout = execa_1.default.commandSync('git status --short', {
      cwd: cwd
    }).stdout;
    return stdout.length > 0;
  } catch (e) {
    return null;
  }
};

exports.default = isGitClean;
module.exports = exports.default;