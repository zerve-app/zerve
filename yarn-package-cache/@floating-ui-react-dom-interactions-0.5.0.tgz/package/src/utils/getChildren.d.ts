import type { FloatingTreeType, ReferenceType } from '../types';
export declare function getChildren<RT extends ReferenceType = ReferenceType>(tree: FloatingTreeType<RT>, id: string | undefined): import("../types").FloatingNodeType<RT>[];
