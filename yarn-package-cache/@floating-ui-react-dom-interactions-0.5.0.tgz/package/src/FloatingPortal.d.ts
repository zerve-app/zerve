import * as React from 'react';
export declare const useFloatingPortalNode: ({ id, enabled, }?: {
    id?: string;
    enabled?: boolean;
}) => HTMLElement;
/**
 * Portals your floating element outside of the main app node.
 * @see https://floating-ui.com/docs/FloatingPortal
 */
export declare const FloatingPortal: ({ children, id, root, }: {
    children?: React.ReactNode;
    id?: string;
    root?: HTMLElement | null;
}) => React.ReactPortal | null;
