/// <reference types="react" />
import { SelectContentProps } from './types';
export declare const SelectContent: ({ children }: SelectContentProps) => import("react").ReactNode;
//# sourceMappingURL=SelectContent.native.d.ts.map